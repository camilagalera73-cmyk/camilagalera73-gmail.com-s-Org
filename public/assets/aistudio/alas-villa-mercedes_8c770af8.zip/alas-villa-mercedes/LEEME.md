# Alas de Villa Mercedes: cómo publicarla

Esta carpeta ya es el sitio completo. No necesita instalar nada: es HTML, CSS y JavaScript.

## 1. Publicar gratis (la forma más fácil)

**Netlify Drop** (sin cuenta técnica, 2 minutos)
1. Entrá a https://app.netlify.com/drop
2. Arrastrá esta carpeta (descomprimida) a la página.
3. Te da un link público, por ejemplo `https://alas-xxxx.netlify.app`. Podés cambiarle el nombre en *Site settings*.

Alternativas: GitHub Pages o Vercel (mismo resultado).

## 2. Reemplazar `TU-DOMINIO`

Una vez que tengas tu link (por ejemplo `alas-villamercedes.netlify.app`), reemplazá `TU-DOMINIO` por ese dominio en estos archivos:
- `index.html` (canonical, og:url y el bloque JSON-LD: 3 lugares)
- `robots.txt`
- `sitemap.xml`

Después volvé a publicar.

## 3. Que aparezca en Google

1. Entrá a https://search.google.com/search-console y agregá tu sitio (propiedad de tipo "Prefijo de URL").
2. Verificá la propiedad (Netlify/Vercel tienen guías; la opción más simple es la etiqueta HTML en el `<head>` de `index.html`).
3. En "Sitemaps" cargá `sitemap.xml`. En "Inspección de URL" pedí la indexación de la página principal.
4. Google puede tardar de unos días a unas semanas. Un dominio propio y que otros sitios te enlacen ayudan a salir mejor posicionada.

## 4. Que se pueda "descargar" (instalar)

La app es una PWA: en el celular (Chrome) aparece "Instalar app" o "Agregar a pantalla de inicio", y en la compu aparece un ícono de instalar en la barra de direcciones. Funciona en parte sin conexión.
Para publicarla en Google Play o App Store hace falta empaquetarla aparte (por ejemplo con PWABuilder) y tener cuenta de desarrollador.

## 5. Pendientes de contenido (están como texto de relleno)

En `index.html` buscá y completá:
- "Completá el contacto local" (centro de fauna / autoridad ambiental)
- "Completá parque o reserva local" (sección Dónde observar)
- "Créditos de fotos: completá las fuentes y licencias correspondientes"
- "Contacto: completá email o red social"
- La nota final "Antes de publicar, verificá..." (borrala cuando termines de revisar)

Las fotos se cargan desde Pexels. Revisá su licencia y dale crédito a cada fotógrafo en el pie de página, o reemplazalas por fotos propias.

## Archivos

- `index.html`: la página
- `tailwind.css`: estilos (ya compilados, no depende de internet)
- `manifest.webmanifest` y `sw.js`: lo que permite instalarla
- `icon-*.png`, `favicon.png`, `apple-touch-icon.png`: íconos
- `robots.txt` y `sitemap.xml`: para Google
